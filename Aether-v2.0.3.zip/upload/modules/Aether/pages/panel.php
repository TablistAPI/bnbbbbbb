<?php
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Aether Template - Panel Backend
 */

if($user->isLoggedIn()){
	if(!$user->canViewACP()){
		// No
		Redirect::to(URL::build('/'));
		die();
	}
	if(!$user->isAdmLoggedIn()){
		// Needs to authenticate
		Redirect::to(URL::build('/panel/auth'));
		die();
	} else {
		if($user->data()->group_id != 2 && !$user->hasPermission('admincp.aether')){
			require_once(ROOT_PATH . '/404.php');
			die();
		}
	}
} else {
	Redirect::to(URL::build('/login'));
	die();
}

define('PAGE', 'panel');
define('PARENT_PAGE', 'aether');
define('PANEL_PAGE', 'aether');
$page_title = $aether_language->get('language', 'aether_title');
require_once(ROOT_PATH . '/core/templates/backend_init.php');

if(isset($_POST['view'])){
	if(Token::check(Input::get('token'))){
		$view = $_POST['view'];
		$getBGColor = $_POST['bg_color'];
		$getFont = $_POST['font'];
		$getBoxMobile = $_POST['box_mobile'];
		$getBG = $_POST['bg'];
		$getBtnBG = $_POST['btn_bg'];
		$getBoxBG = $_POST['box_bg'];
		$getBoxMargin = $_POST['box_margin'];
		$getPortal1Name = $_POST['portal1_name'];
		$getPortal2Name = $_POST['portal2_name'];
		$getPortal3Name = $_POST['portal3_name'];
		$getPortal4Name = $_POST['portal4_name'];
		$getPortal1Icon = $_POST['portal1_icon'];
		$getPortal2Icon = $_POST['portal2_icon'];
		$getPortal3Icon = $_POST['portal3_icon'];
		$getPortal4Icon = $_POST['portal4_icon'];
		$getPortal1Link = $_POST['portal1_link'];
		$getPortal2Link = $_POST['portal2_link'];
		$getPortal3Link = $_POST['portal3_link'];
		$getPortal4Link = $_POST['portal4_link'];
		$getPortalBg = $_POST['portalbg'];
		$getLOGO = $_POST['logo']; 
		$getCOverlay = $_POST['coverlay'];
		$getFA = $_POST['fa'];
		$getGA = $_POST['ga'];
		$getP = $_POST['p_color'];
		$getS = $_POST['s_color'];
		$getLogoSize = $_POST['logo_size'];
		$getLogoSizeM = $_POST['logo_size_m'];
		$getLogoMargin = $_POST['logo_margin'];
		$getLogoMarginM = $_POST['logo_margin_m'];
		$getDiscordServer = $_POST['discord_server']; 
		$getFavicon = $_POST['favicon']; 
		$getAlertText = $_POST['alert_text']; 
		$getDiscordBox = $_POST['discord_box']; 
		$getServerBox = $_POST['server_box'];  
		$getAlertTitle = $_POST['alert_title'];
		$getAnnounceText = $_POST['announce_text']; 
		$getAnnounceTitle = $_POST['announce_title'];
		$getSlider1Title = $_POST['slider1_title'];
		$getSlider1Desc = $_POST['slider1_desc'];
		$getSlider1Image = $_POST['slider1_image'];
		$getSlider1Link = $_POST['slider1_link'];
		$getSlider2Title = $_POST['slider2_title'];
		$getSlider2Desc = $_POST['slider2_desc'];
		$getSlider2Image = $_POST['slider2_image'];
		$getSlider2Link = $_POST['slider2_link'];
		$getSlider3Title = $_POST['slider3_title'];
		$getSlider3Desc = $_POST['slider3_desc'];
		$getSlider3Image = $_POST['slider3_image'];
		$getSlider3Link = $_POST['slider3_link'];
		$getSlider4Title = $_POST['slider4_title'];
		$getSlider4Desc = $_POST['slider4_desc'];
		$getSlider4Image = $_POST['slider4_image'];
		$getSlider4Link = $_POST['slider4_link'];
		$getSlider5Title = $_POST['slider5_title'];
		$getSlider5Desc = $_POST['slider5_desc'];
		$getSlider5Image = $_POST['slider5_image'];
		$getSlider5Link = $_POST['slider5_link'];
		$getSlider1DColor = $_POST['slider1_dcolor'];
		$getSlider1TColor = $_POST['slider1_tcolor'];
		$getSlider2DColor = $_POST['slider2_dcolor'];
		$getSlider2TColor = $_POST['slider2_tcolor'];
		$getSlider3DColor = $_POST['slider3_dcolor'];
		$getSlider3TColor = $_POST['slider3_tcolor'];
		$getSlider4DColor = $_POST['slider4_dcolor'];
		$getSlider4TColor = $_POST['slider4_tcolor'];
		$getSlider5DColor = $_POST['slider5_dcolor'];
		$getSlider5TColor = $_POST['slider5_tcolor'];
	} else
		$errors = array($language->get('general', 'invalid_token'));
} else
	$view = null;

if($view == "update"){
	$f = fopen(ROOT_PATH . "/modules/Aether/pages/settings.php","w");
	require ROOT_PATH . '/modules/Aether/pages/settings.default.php';

	if(fwrite($f, $settings_inf) > 0){
		fclose($f);

		Session::flash('aether_success', $aether_language->get('language', 'successfully_updated'));

		Redirect::to(URL::build('/panel/aether'));
		die();

	} else
		$errors = array($aether_language->get('language', 'unable_to_write_to_settings'));

}

Module::loadPage($user, $pages, $cache, $smarty, array($navigation, $cc_nav, $mod_nav), $widgets);

if(Session::exists('aether_success'))
	$success = Session::flash('aether_success');

if(isset($success))
	$smarty->assign(array(
		'SUCCESS' => $success,
		'SUCCESS_TITLE' => $language->get('general', 'success')
	));

if(isset($errors) && count($errors))
	$smarty->assign(array(
		'ERRORS' => $errors,
		'ERRORS_TITLE' => $language->get('general', 'error')
	));

require ROOT_PATH . '/modules/Aether/pages/settings.php';
$getNavbarBg = THEME_BG;
$getFA = THEME_FA;
$getGA = THEME_GA;
$getBoxMargin = THEME_BOX_MARGIN;
$getBoxBG = THEME_BOX_BG;
$getBtnBG = THEME_BTN_BG;
$getFont = THEME_FONT;
$getBGColor = THEME_BG_COLOR;
$getBoxMobile = THEME_BOX_MOBILE;
$getS = THEME_S_COLOR;
$getP = THEME_P_COLOR;
$getLogoSize = THEME_LOGO_SIZE;
$getLogoSizeM = THEME_LOGO_SIZE_M;
$getLogoMargin = THEME_LOGO_MARGIN;
$getLogoMarginM = THEME_LOGO_MARGIN_M;
$getCOverlay = THEME_C_OVERLAY;
$getPortalBg = THEME_PORTAL_BG;
$getPortal1Name = PORTAL_1_NAME;
$getPortal2Name = PORTAL_2_NAME;
$getPortal3Name = PORTAL_3_NAME;
$getPortal4Name = PORTAL_4_NAME;
$getPortal1Icon = PORTAL_1_ICON;
$getPortal2Icon = PORTAL_2_ICON;
$getPortal3Icon = PORTAL_3_ICON;
$getPortal4Icon = PORTAL_4_ICON;
$getPortal1Link = PORTAL_1_LINK;
$getPortal2Link = PORTAL_2_LINK;
$getPortal3Link = PORTAL_3_LINK;
$getPortal4Link = PORTAL_4_LINK;
$getNavbarLogo = THEME_LOGO;
$getPageFavicon = THEME_FAVICON;
$getDiscordServer = THEME_DISCORD_SERVER;
$getAlertText = THEME_ALERT_TEXT;
$getAlertTitle = THEME_ALERT_TITLE;
$getDiscordBox = THEME_DISCORD_BOX;
$getServerBox = THEME_SERVER_BOX;
$getAnnounceText = THEME_ANNOUNCE_TEXT;
$getAnnounceTitle = THEME_ANNOUNCE_TITLE;
$getSlider1Title = THEME_SLIDER1_TITLE;
$getSlider1Desc = THEME_SLIDER1_DESCRIPTION;
$getSlider1Image = THEME_SLIDER1_IMAGE;
$getSlider1Link = THEME_SLIDER1_LINK;
$getSlider2Title = THEME_SLIDER2_TITLE;
$getSlider2Desc = THEME_SLIDER2_DESCRIPTION;
$getSlider2Image = THEME_SLIDER2_IMAGE;
$getSlider2Link = THEME_SLIDER2_LINK;
$getSlider3Title = THEME_SLIDER3_TITLE;
$getSlider3Desc = THEME_SLIDER3_DESCRIPTION;
$getSlider3Image = THEME_SLIDER3_IMAGE;
$getSlider3Link = THEME_SLIDER4_LINK;
$getSlider4Title = THEME_SLIDER4_TITLE;
$getSlider4Desc = THEME_SLIDER4_DESCRIPTION;
$getSlider4Image = THEME_SLIDER4_IMAGE;
$getSlider4Link = THEME_SLIDER4_LINK;
$getSlider5Title = THEME_SLIDER5_TITLE;
$getSlider5Desc = THEME_SLIDER5_DESCRIPTION;
$getSlider5Image = THEME_SLIDER5_IMAGE;
$getSlider5Link = THEME_SLIDER5_LINK;
$getSlider1DColor = THEME_SLIDER1_DCOLOR;
$getSlider1TColor = THEME_SLIDER1_TCOLOR;
$getSlider2DColor = THEME_SLIDER2_DCOLOR;
$getSlider2TColor = THEME_SLIDER2_TCOLOR;
$getSlider3DColor = THEME_SLIDER3_DCOLOR;
$getSlider3TColor = THEME_SLIDER3_TCOLOR;
$getSlider4DColor = THEME_SLIDER4_DCOLOR;
$getSlider4TColor = THEME_SLIDER4_TCOLOR;
$getSlider5DColor = THEME_SLIDER5_DCOLOR;
$getSlider5TColor = THEME_SLIDER5_TCOLOR;


$smarty->assign(array(
	'PARENT_PAGE' => PARENT_PAGE,
	'DASHBOARD' => $language->get('admin', 'dashboard'),
	'AETHER' => $aether_language->get('language', 'aether_title'),
	'PAGE' => PANEL_PAGE,
	'TOKEN' => Token::get(),
	'SUBMIT' => $language->get('general', 'submit'),
	'FAVICON_VALUE' => $getPageFavicon,
	'HEADER_BG_VALUE' => $getNavbarBg,
	'LOGO_VALUE' => $getNavbarLogo,
	'FA_VALUE' => $getFA,
	'GA_VALUE' => $getGA,
	'BOX_MARGIN_VALUE' => $getBoxMargin,
	'BOX_BG_VALUE' => $getBoxBG,
	'BTN_BG_VALUE' => $getBtnBG,
	'FONT_VALUE' => $getFont,
	'BOX_MOBILE_VALUE' => $getBoxMobile,
	'BG_COLOR_VALUE' => $getBGColor,
	'S_COLOR_VALUE' => $getS,
	'P_COLOR_VALUE' => $getP,
	'LOGO_SIZE_VALUE' => $getLogoSize,
	'LOGO_SIZE_M_VALUE' => $getLogoSizeM,
	'LOGO_MARGIN_VALUE' => $getLogoMargin,
	'LOGO_MARGIN_M_VALUE' => $getLogoMarginM,
	'COVERLAY_VALUE' => $getCOverlay,
	'PORTAL_BG_VALUE' => $getPortalBg,
	'PORTAL1_NAME_VALUE' => $getPortal1Name,
	'PORTAL2_NAME_VALUE' => $getPortal2Name,
	'PORTAL3_NAME_VALUE' => $getPortal3Name,
	'PORTAL4_NAME_VALUE' => $getPortal4Name,
	'PORTAL1_ICON_VALUE' => $getPortal1Icon,
	'PORTAL2_ICON_VALUE' => $getPortal2Icon,
	'PORTAL3_ICON_VALUE' => $getPortal3Icon,
	'PORTAL4_ICON_VALUE' => $getPortal4Icon,
	'PORTAL1_LINK_VALUE' => $getPortal1Link,
	'PORTAL2_LINK_VALUE' => $getPortal2Link,
	'PORTAL3_LINK_VALUE' => $getPortal3Link,
	'PORTAL4_LINK_VALUE' => $getPortal4Link,
	'ALERT_TEXT_VALUE' => $getAlertText,
	'ALERT_TITLE_VALUE' => $getAlertTitle,
	'ANNOUNCE_TEXT_VALUE' => $getAnnounceText,
	'ANNOUNCE_TITLE_VALUE' => $getAnnounceTitle,
	'DISCORD_BOX_VALUE' => $getDiscordBox,
	'SERVER_BOX_VALUE' => $getServerBox,
	'DISCORD_SERVER_VALUE' => $getDiscordServer,
	'SLIDER1_TITLE_VALUE' => $getSlider1Title,
	'SLIDER1_DESC_VALUE' => $getSlider1Desc,
	'SLIDER1_IMAGE_VALUE' => $getSlider1Image,
	'SLIDER1_LINK_VALUE' => $getSlider1Link,
	'SLIDER2_TITLE_VALUE' => $getSlider2Title,
	'SLIDER2_DESC_VALUE' => $getSlider2Desc,
	'SLIDER2_IMAGE_VALUE' => $getSlider2Image,
	'SLIDER2_LINK_VALUE' => $getSlider2Link,
	'SLIDER3_TITLE_VALUE' => $getSlider3Title,
	'SLIDER3_DESC_VALUE' => $getSlider3Desc,
	'SLIDER3_IMAGE_VALUE' => $getSlider3Image,
	'SLIDER3_LINK_VALUE' => $getSlider3Link,
	'SLIDER4_TITLE_VALUE' => $getSlider4Title,
	'SLIDER4_DESC_VALUE' => $getSlider4Desc,
	'SLIDER4_IMAGE_VALUE' => $getSlider4Image,
	'SLIDER4_LINK_VALUE' => $getSlider4Link,
	'SLIDER5_TITLE_VALUE' => $getSlider5Title,
	'SLIDER5_DESC_VALUE' => $getSlider5Desc,
	'SLIDER5_IMAGE_VALUE' => $getSlider5Image,
	'SLIDER5_LINK_VALUE' => $getSlider5Link,
	'SLIDER1_TCOLOR_VALUE' => $getSlider1TColor,
	'SLIDER1_DCOLOR_VALUE' => $getSlider1DColor,
	'SLIDER2_TCOLOR_VALUE' => $getSlider2TColor,
	'SLIDER2_DCOLOR_VALUE' => $getSlider2DColor,
	'SLIDER3_TCOLOR_VALUE' => $getSlider3TColor,
	'SLIDER3_DCOLOR_VALUE' => $getSlider3DColor,
	'SLIDER4_TCOLOR_VALUE' => $getSlider4TColor,
	'SLIDER4_DCOLOR_VALUE' => $getSlider4DColor,
	'SLIDER5_TCOLOR_VALUE' => $getSlider5TColor,
	'SLIDER5_DCOLOR_VALUE' => $getSlider5DColor,
	'PORTAL_BG' => $aether_language->get('language', 'portal_bg'),
	'BOX_BG' => $aether_language->get('language', 'box_bg'),
	'BTN_BG' => $aether_language->get('language', 'btn_bg'),
	'BOX_MARGIN' => $aether_language->get('language', 'box_margin'),
	'LOGO_SIZE' => $aether_language->get('language', 'logo_size'),
	'LOGO_SIZE_M' => $aether_language->get('language', 'logo_size_m'),
	'LOGO_MARGIN' => $aether_language->get('language', 'logo_margin'),
	'LOGO_MARGIN_M' => $aether_language->get('language', 'logo_margin_m'),
	'COVERLAY' => $aether_language->get('language', 'coverlay'),
	'SLIDER1_TITLE' => $aether_language->get('language', 'slider1_title'),
	'SLIDER1_DESC' => $aether_language->get('language', 'slider1_desc'),
	'SLIDER1_IMAGE' => $aether_language->get('language', 'slider1_image'),
	'SLIDER1_LINK' => $aether_language->get('language', 'slider1_link'),
	'SLIDER2_TITLE' => $aether_language->get('language', 'slider2_title'),
	'SLIDER2_DESC' => $aether_language->get('language', 'slider2_desc'),
	'SLIDER2_IMAGE' => $aether_language->get('language', 'slider2_image'),
	'SLIDER2_LINK' => $aether_language->get('language', 'slider2_link'),
	'SLIDER3_TITLE' => $aether_language->get('language', 'slider3_title'),
	'SLIDER3_DESC' => $aether_language->get('language', 'slider3_desc'),
	'SLIDER3_IMAGE' => $aether_language->get('language', 'slider3_image'),
	'SLIDER3_LINK' => $aether_language->get('language', 'slider3_link'),
	'SLIDER4_TITLE' => $aether_language->get('language', 'slider4_title'),
	'SLIDER4_DESC' => $aether_language->get('language', 'slider4_desc'),
	'SLIDER4_IMAGE' => $aether_language->get('language', 'slider4_image'),
	'SLIDER4_LINK' => $aether_language->get('language', 'slider4_link'),
	'SLIDER5_TITLE' => $aether_language->get('language', 'slider5_title'),
	'SLIDER5_DESC' => $aether_language->get('language', 'slider5_desc'),
	'SLIDER5_IMAGE' => $aether_language->get('language', 'slider5_image'),
	'SLIDER5_LINK' => $aether_language->get('language', 'slider5_link'),
	'FAVICON' => $aether_language->get('language', 'favicon'),
	'HEADER_BG' => $aether_language->get('language', 'header_background'),
	'DISCORD_SERVER' =>$aether_language->get('language', 'discord_server'),
	'LOGO' => $aether_language->get('language', 'logo'),
	'FA' => $aether_language->get('language', 'fa'),
	'GA' => $aether_language->get('language', 'ga'),
	'GENERAL' => $aether_language->get('language', 'general'),
	'COLORS' => $aether_language->get('language', 'colors'),
	'AA' => $aether_language->get('language', 'aa'),
	'SLIDER' => $aether_language->get('language', 'slider'),
	'DS' => $aether_language->get('language', 'ds'),
	'PORTAL' => $aether_language->get('language', 'portal'),
	'ADVANCED' => $aether_language->get('language', 'advanced'),
	'MONTSERRAT' => $aether_language->get('language', 'montserrat'),
	'CODA' => $aether_language->get('language', 'coda'),
	'BOX_MOBILE' => $aether_language->get('language', 'box_mobile'),
	'FONT' => $aether_language->get('language', 'font'),
	'BG_COLOR' => $aether_language->get('language', 'bg_color'),
	'P_COLOR' => $aether_language->get('language', 'p_color'),
	'S_COLOR' => $aether_language->get('language', 's_color'),
	'ALERT_TITLE' => $aether_language->get('language', 'alert_title'),
	'ALERT_TEXT' => $aether_language->get('language', 'alert_text'),
	'ANNOUNCE_TITLE' => $aether_language->get('language', 'announce_title'),
	'ANNOUNCE_TEXT' => $aether_language->get('language', 'announce_text'),
	'DISCORD_BOX' => $aether_language->get('language', 'discord_box'),
	'SERVER_BOX' => $aether_language->get('language', 'server_box'),
	'YES' => $aether_language->get('language', 'yes'),
	'NO' => $aether_language->get('language', 'no'),
	'DCOLOR' => $aether_language->get('language', 'dcolor'),
	'TCOLOR' => $aether_language->get('language', 'tcolor'),
	'PORTAL1_NAME' => $aether_language->get('language', 'portal1_name'),
	'PORTAL2_NAME' => $aether_language->get('language', 'portal2_name'),
	'PORTAL3_NAME' => $aether_language->get('language', 'portal3_name'),
	'PORTAL4_NAME' => $aether_language->get('language', 'portal4_name'),
	'PORTAL1_ICON' => $aether_language->get('language', 'portal1_icon'),
	'PORTAL2_ICON' => $aether_language->get('language', 'portal2_icon'),
	'PORTAL3_ICON' => $aether_language->get('language', 'portal3_icon'),
	'PORTAL4_ICON' => $aether_language->get('language', 'portal4_icon'),
	'PORTAL1_LINK' => $aether_language->get('language', 'portal1_link'),
	'PORTAL2_LINK' => $aether_language->get('language', 'portal2_link'),
	'PORTAL3_LINK' => $aether_language->get('language', 'portal3_link'),
	'PORTAL4_LINK' => $aether_language->get('language', 'portal4_link'),
	'HOME' => $aether_language->get('language', 'home'),
	'ALL' => $aether_language->get('language', 'all')
));

$page_load = microtime(true) - $start;
define('PAGE_LOAD_TIME', str_replace('{x}', round($page_load, 3), $language->get('general', 'page_loaded_in')));

$template->onPageLoad();

require(ROOT_PATH . '/core/templates/panel_navbar.php');

$template->displayTemplate('aether/index.tpl', $smarty);