<?php
$settings_inf="<?php

	if(!defined('THEME_FA'))
	define('THEME_FA', '".$getFA."');

	if(!defined('THEME_GA'))
	define('THEME_GA', '".$getGA."');

	if(!defined('THEME_LOGO_SIZE'))
	define('THEME_LOGO_SIZE', '".$getLogoSize."');

	if(!defined('THEME_LOGO_SIZE_M'))
	define('THEME_LOGO_SIZE_M', '".$getLogoSizeM."');

	if(!defined('THEME_LOGO_MARGIN'))
	define('THEME_LOGO_MARGIN', '".$getLogoMargin."');

	if(!defined('THEME_LOGO_MARGIN_M'))
	define('THEME_LOGO_MARGIN_M', '".$getLogoMarginM."');

	if(!defined('THEME_C_OVERLAY'))
	define('THEME_C_OVERLAY', '".$getCOverlay."');

	if(!defined('THEME_FONT'))
	define('THEME_FONT', '".$getFont."');

	if(!defined('THEME_BOX_BG'))
	define('THEME_BOX_BG', '".$getBoxBG."');

	if(!defined('THEME_BOX_MARGIN'))
	define('THEME_BOX_MARGIN', '".$getBoxMargin."');

	if(!defined('THEME_BTN_BG'))
	define('THEME_BTN_BG', '".$getBtnBG."');

	if(!defined('THEME_BOX_MOBILE'))
	define('THEME_BOX_MOBILE', '".$getBoxMobile."');

	if(!defined('THEME_BG_COLOR'))
	define('THEME_BG_COLOR', '".$getBGColor."');

	if(!defined('THEME_P_COLOR'))
	define('THEME_P_COLOR', '".$getP."');

	if(!defined('THEME_S_COLOR'))
	define('THEME_S_COLOR', '".$getS."');
	
	if(!defined('THEME_DISCORD_SERVER'))
	define('THEME_DISCORD_SERVER', '".$getDiscordServer."');

	if(!defined('THEME_BG'))
	define('THEME_BG', '".$getBG."');

	if(!defined('THEME_ALERT_TITLE'))
	define('THEME_ALERT_TITLE', '".$getAlertTitle."');
	
	if(!defined('THEME_ALERT_TEXT'))
	define('THEME_ALERT_TEXT', '".$getAlertText."');
	
	if(!defined('THEME_ANNOUNCE_TITLE'))
	define('THEME_ANNOUNCE_TITLE', '".$getAnnounceTitle."');
	
	if(!defined('THEME_ANNOUNCE_TEXT'))
	define('THEME_ANNOUNCE_TEXT', '".$getAnnounceText."');
	
	if(!defined('THEME_FAVICON'))
	define('THEME_FAVICON', '".$getFavicon."');

	if(!defined('THEME_DISCORD_BOX'))
	define('THEME_DISCORD_BOX', '".$getDiscordBox."');

	if(!defined('THEME_SERVER_BOX'))
	define('THEME_SERVER_BOX', '".$getServerBox."');

	if(!defined('THEME_LOGO'))
	define('THEME_LOGO', '".$getLOGO."');
	
	if(!defined('THEME_SLIDER1_TITLE'))
	define('THEME_SLIDER1_TITLE', '".$getSlider1Title."');
	
	if(!defined('THEME_SLIDER2_TITLE'))
	define('THEME_SLIDER2_TITLE', '".$getSlider2Title."');
	
	if(!defined('THEME_SLIDER3_TITLE'))
	define('THEME_SLIDER3_TITLE', '".$getSlider3Title."');
	
	if(!defined('THEME_SLIDER4_TITLE'))
	define('THEME_SLIDER4_TITLE', '".$getSlider4Title."');
	
	if(!defined('THEME_SLIDER5_TITLE'))
	define('THEME_SLIDER5_TITLE', '".$getSlider5Title."');
	
	if(!defined('THEME_SLIDER1_DESCRIPTION'))
	define('THEME_SLIDER1_DESCRIPTION', '".$getSlider1Desc."');
	
	if(!defined('THEME_SLIDER2_DESCRIPTION'))
	define('THEME_SLIDER2_DESCRIPTION', '".$getSlider2Desc."');
	
	if(!defined('THEME_SLIDER3_DESCRIPTION'))
	define('THEME_SLIDER3_DESCRIPTION', '".$getSlider3Desc."');
	
	if(!defined('THEME_SLIDER4_DESCRIPTION'))
	define('THEME_SLIDER4_DESCRIPTION', '".$getSlider4Desc."');
	
	if(!defined('THEME_SLIDER5_DESCRIPTION'))
	define('THEME_SLIDER5_DESCRIPTION', '".$getSlider5Desc."');
	
	if(!defined('THEME_SLIDER1_IMAGE'))
	define('THEME_SLIDER1_IMAGE', '".$getSlider1Image."');
	
	if(!defined('THEME_SLIDER2_IMAGE'))
	define('THEME_SLIDER2_IMAGE', '".$getSlider2Image."');
	
	if(!defined('THEME_SLIDER3_IMAGE'))
	define('THEME_SLIDER3_IMAGE', '".$getSlider3Image."');
	
	if(!defined('THEME_SLIDER4_IMAGE'))
	define('THEME_SLIDER4_IMAGE', '".$getSlider4Image."');
	
	if(!defined('THEME_SLIDER5_IMAGE'))
	define('THEME_SLIDER5_IMAGE', '".$getSlider5Image."');
	
	if(!defined('THEME_SLIDER1_LINK'))
	define('THEME_SLIDER1_LINK', '".$getSlider1Link."');
	
	if(!defined('THEME_SLIDER2_LINK'))
	define('THEME_SLIDER2_LINK', '".$getSlider2Link."');
	
	if(!defined('THEME_SLIDER3_LINK'))
	define('THEME_SLIDER3_LINK', '".$getSlider3Link."');
	
	if(!defined('THEME_SLIDER4_LINK'))
	define('THEME_SLIDER4_LINK', '".$getSlider4Link."');
	
	if(!defined('THEME_SLIDER5_LINK'))
	define('THEME_SLIDER5_LINK', '".$getSlider5Link."');
	
	if(!defined('PORTAL_1_LINK'))
	define('PORTAL_1_LINK', '".$getPortal1Link."');
	
	if(!defined('PORTAL_2_LINK'))
	define('PORTAL_2_LINK', '".$getPortal2Link."');
	
	if(!defined('PORTAL_3_LINK'))
	define('PORTAL_3_LINK', '".$getPortal3Link."');
	
	if(!defined('PORTAL_4_LINK'))
	define('PORTAL_4_LINK', '".$getPortal4Link."');
	
	if(!defined('PORTAL_1_NAME'))
	define('PORTAL_1_NAME', '".$getPortal1Name."');
	
	if(!defined('PORTAL_2_NAME'))
	define('PORTAL_2_NAME', '".$getPortal2Name."');
	
	if(!defined('PORTAL_3_NAME'))
	define('PORTAL_3_NAME', '".$getPortal3Name."');
	
	if(!defined('PORTAL_4_NAME'))
	define('PORTAL_4_NAME', '".$getPortal4Name."');
	
	if(!defined('PORTAL_1_ICON'))
	define('PORTAL_1_ICON', '".$getPortal1Icon."');
	
	if(!defined('PORTAL_2_ICON'))
	define('PORTAL_2_ICON', '".$getPortal2Icon."');
	
	if(!defined('PORTAL_3_ICON'))
	define('PORTAL_3_ICON', '".$getPortal3Icon."');
	
	if(!defined('PORTAL_4_ICON'))
	define('PORTAL_4_ICON', '".$getPortal4Icon."');
	
	if(!defined('THEME_PORTAL_BG'))
	define('THEME_PORTAL_BG', '".$getPortalBg."');

	if(!defined('THEME_SLIDER1_DCOLOR'))
	define('THEME_SLIDER1_DCOLOR', '".$getSlider1DColor."');

	if(!defined('THEME_SLIDER1_TCOLOR'))
	define('THEME_SLIDER1_TCOLOR', '".$getSlider1TColor."');

	if(!defined('THEME_SLIDER2_DCOLOR'))
	define('THEME_SLIDER2_DCOLOR', '".$getSlider2DColor."');

	if(!defined('THEME_SLIDER2_TCOLOR'))
	define('THEME_SLIDER2_TCOLOR', '".$getSlider2TColor."');

	if(!defined('THEME_SLIDER3_DCOLOR'))
	define('THEME_SLIDER3_DCOLOR', '".$getSlider3DColor."');

	if(!defined('THEME_SLIDER3_TCOLOR'))
	define('THEME_SLIDER3_TCOLOR', '".$getSlider3TColor."');

	if(!defined('THEME_SLIDER4_DCOLOR'))
	define('THEME_SLIDER4_DCOLOR', '".$getSlider4DColor."');

	if(!defined('THEME_SLIDER4_TCOLOR'))
	define('THEME_SLIDER4_TCOLOR', '".$getSlider4TColor."');

	if(!defined('THEME_SLIDER5_DCOLOR'))
	define('THEME_SLIDER5_DCOLOR', '".$getSlider5DColor."');

	if(!defined('THEME_SLIDER5_TCOLOR'))
	define('THEME_SLIDER5_TCOLOR', '".$getSlider5TColor."');

?>";
?>