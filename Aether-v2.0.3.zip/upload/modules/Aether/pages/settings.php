<?php

	if(!defined('THEME_FA'))
	define('THEME_FA', '');

	if(!defined('THEME_GA'))
	define('THEME_GA', '');

	if(!defined('THEME_LOGO_SIZE'))
	define('THEME_LOGO_SIZE', '250px');

	if(!defined('THEME_LOGO_SIZE_M'))
	define('THEME_LOGO_SIZE_M', '200px');

	if(!defined('THEME_LOGO_MARGIN'))
	define('THEME_LOGO_MARGIN', '-200px');

	if(!defined('THEME_LOGO_MARGIN_M'))
	define('THEME_LOGO_MARGIN_M', '-150px');

	if(!defined('THEME_C_OVERLAY'))
	define('THEME_C_OVERLAY', 'no');

	if(!defined('THEME_FONT'))
	define('THEME_FONT', 'Montserrat');

	if(!defined('THEME_BOX_BG'))
	define('THEME_BOX_BG', '#202020');

	if(!defined('THEME_BOX_MARGIN'))
	define('THEME_BOX_MARGIN', '-90px');

	if(!defined('THEME_BTN_BG'))
	define('THEME_BTN_BG', '#202020');

	if(!defined('THEME_BOX_MOBILE'))
	define('THEME_BOX_MOBILE', 'yes');

	if(!defined('THEME_BG_COLOR'))
	define('THEME_BG_COLOR', '#f7f7f7');

	if(!defined('THEME_P_COLOR'))
	define('THEME_P_COLOR', '#0066cc');

	if(!defined('THEME_S_COLOR'))
	define('THEME_S_COLOR', '#202020');
	
	if(!defined('THEME_DISCORD_SERVER'))
	define('THEME_DISCORD_SERVER', 'discord.gg/example');

	if(!defined('THEME_BG'))
	define('THEME_BG', '/custom/templates/Aether/img/bg.jpg');

	if(!defined('THEME_ALERT_TITLE'))
	define('THEME_ALERT_TITLE', '');
	
	if(!defined('THEME_ALERT_TEXT'))
	define('THEME_ALERT_TEXT', 'This is a test alert! This message is configurable in StaffCP -> Aether');
	
	if(!defined('THEME_ANNOUNCE_TITLE'))
	define('THEME_ANNOUNCE_TITLE', '');
	
	if(!defined('THEME_ANNOUNCE_TEXT'))
	define('THEME_ANNOUNCE_TEXT', 'This is a test announcement! This message is configurable in StaffCP -> Aether');
	
	if(!defined('THEME_FAVICON'))
	define('THEME_FAVICON', '/custom/templates/Aether/img/favicon.jpeg');

	if(!defined('THEME_DISCORD_BOX'))
	define('THEME_DISCORD_BOX', 'yes');

	if(!defined('THEME_SERVER_BOX'))
	define('THEME_SERVER_BOX', 'yes');

	if(!defined('THEME_LOGO'))
	define('THEME_LOGO', '/custom/templates/Aether/img/logo.png');
	
	if(!defined('THEME_SLIDER1_TITLE'))
	define('THEME_SLIDER1_TITLE', 'Slider #1');
	
	if(!defined('THEME_SLIDER2_TITLE'))
	define('THEME_SLIDER2_TITLE', 'Slider #2');
	
	if(!defined('THEME_SLIDER3_TITLE'))
	define('THEME_SLIDER3_TITLE', 'Slider #3');
	
	if(!defined('THEME_SLIDER4_TITLE'))
	define('THEME_SLIDER4_TITLE', 'Slider #4');
	
	if(!defined('THEME_SLIDER5_TITLE'))
	define('THEME_SLIDER5_TITLE', 'Slider #5');
	
	if(!defined('THEME_SLIDER1_DESCRIPTION'))
	define('THEME_SLIDER1_DESCRIPTION', 'Configure this slider in StaffCP -> Aether');
	
	if(!defined('THEME_SLIDER2_DESCRIPTION'))
	define('THEME_SLIDER2_DESCRIPTION', 'Configure this slider in StaffCP -> Aether');
	
	if(!defined('THEME_SLIDER3_DESCRIPTION'))
	define('THEME_SLIDER3_DESCRIPTION', 'Configure this slider in StaffCP -> Aether');
	
	if(!defined('THEME_SLIDER4_DESCRIPTION'))
	define('THEME_SLIDER4_DESCRIPTION', 'Configure this slider in StaffCP -> Aether');
	
	if(!defined('THEME_SLIDER5_DESCRIPTION'))
	define('THEME_SLIDER5_DESCRIPTION', 'Configure this slider in StaffCP -> Aether');
	
	if(!defined('THEME_SLIDER1_IMAGE'))
	define('THEME_SLIDER1_IMAGE', '/custom/templates/Aether/img/slider.jpg');
	
	if(!defined('THEME_SLIDER2_IMAGE'))
	define('THEME_SLIDER2_IMAGE', '/custom/templates/Aether/img/slider.jpg');
	
	if(!defined('THEME_SLIDER3_IMAGE'))
	define('THEME_SLIDER3_IMAGE', '/custom/templates/Aether/img/slider.jpg');
	
	if(!defined('THEME_SLIDER4_IMAGE'))
	define('THEME_SLIDER4_IMAGE', '/custom/templates/Aether/img/slider.jpg');
	
	if(!defined('THEME_SLIDER5_IMAGE'))
	define('THEME_SLIDER5_IMAGE', '/custom/templates/Aether/img/slider.jpg');
	
	if(!defined('THEME_SLIDER1_LINK'))
	define('THEME_SLIDER1_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER2_LINK'))
	define('THEME_SLIDER2_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER3_LINK'))
	define('THEME_SLIDER3_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER4_LINK'))
	define('THEME_SLIDER4_LINK', 'https://google.com');
	
	if(!defined('THEME_SLIDER5_LINK'))
	define('THEME_SLIDER5_LINK', 'https://google.com');
	
	if(!defined('PORTAL_1_LINK'))
	define('PORTAL_1_LINK', '/forums');
	
	if(!defined('PORTAL_2_LINK'))
	define('PORTAL_2_LINK', '/store');
	
	if(!defined('PORTAL_3_LINK'))
	define('PORTAL_3_LINK', '/members');
	
	if(!defined('PORTAL_4_LINK'))
	define('PORTAL_4_LINK', '/vote');
	
	if(!defined('PORTAL_1_NAME'))
	define('PORTAL_1_NAME', 'Forum');
	
	if(!defined('PORTAL_2_NAME'))
	define('PORTAL_2_NAME', 'Store');
	
	if(!defined('PORTAL_3_NAME'))
	define('PORTAL_3_NAME', 'Members');
	
	if(!defined('PORTAL_4_NAME'))
	define('PORTAL_4_NAME', 'Vote');
	
	if(!defined('PORTAL_1_ICON'))
	define('PORTAL_1_ICON', 'fas fa-comments');
	
	if(!defined('PORTAL_2_ICON'))
	define('PORTAL_2_ICON', 'fas fa-store-alt');
	
	if(!defined('PORTAL_3_ICON'))
	define('PORTAL_3_ICON', 'fas fa-users');
	
	if(!defined('PORTAL_4_ICON'))
	define('PORTAL_4_ICON', 'fas fa-thumbs-up');
	
	if(!defined('THEME_PORTAL_BG'))
	define('THEME_PORTAL_BG', '/custom/templates/Aether/img/bg.jpg');

	if(!defined('THEME_SLIDER1_DCOLOR'))
	define('THEME_SLIDER1_DCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER1_TCOLOR'))
	define('THEME_SLIDER1_TCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER2_DCOLOR'))
	define('THEME_SLIDER2_DCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER2_TCOLOR'))
	define('THEME_SLIDER2_TCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER3_DCOLOR'))
	define('THEME_SLIDER3_DCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER3_TCOLOR'))
	define('THEME_SLIDER3_TCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER4_DCOLOR'))
	define('THEME_SLIDER4_DCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER4_TCOLOR'))
	define('THEME_SLIDER4_TCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER5_DCOLOR'))
	define('THEME_SLIDER5_DCOLOR', '#FFFFFF');

	if(!defined('THEME_SLIDER5_TCOLOR'))
	define('THEME_SLIDER5_TCOLOR', '#FFFFFF');

?>