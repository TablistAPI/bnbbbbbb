<?php 
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Aether Template
 */

class Aether_Module extends Module {
	private $_language, $_aether_language;

	public function __construct($pages, $language, $aether_language){
		$this->_language = $language;
		$this->_aether_language = $aether_language;

		$name = 'Aether';
		$author = '<a href="https://coldfiredev.cf" target="_blank" rel="nofollow noopener">Coldfire</a>';
		$module_version = '2.0.3';
		$nameless_version = '2.0.0-pr7';

		parent::__construct($this, $name, $author, $module_version, $nameless_version);

		// Pages
		$pages->add('Aether', '/panel/aether', 'pages/panel.php');
	}

	public function onInstall(){
		// Copy panel template
		if(!is_dir(ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/aether')){
			try {
				mkdir(ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/aether');
				copy(ROOT_PATH . '/custom/panel_templates/Default/aether/index.tpl', ROOT_PATH . '/custom/panel_templates/' . PANEL_TEMPLATE . '/aether/index.tpl');
			} catch(Exception $e){
				// Unable to copy
			}
		}
	}

	public function onUninstall(){
		// Not necessary
	}

	public function onEnable(){
		// Not necessary
	}

	public function onDisable(){
		// Not necessary
	}

	public function onPageLoad($user, $pages, $cache, $smarty, $navs, $widgets, $template){
		// Permissions
		PermissionHandler::registerPermissions('Aether', array(
			'admincp.aether' => $this->_language->get('moderator', 'staff_cp') . ' &raquo; Aether'
		));
		if(defined('FRONT_END')){
			require(ROOT_PATH . '/modules/Aether/pages/getvariables.php');
			$smarty->assign(array(
				'DISCORD_BOX_COPY' => $this->_aether_language->get('language', 'discord_box_copy'),
				'LATEST_POST' => $this->_aether_language->get('language', 'latest_post'),
				'FA_1' => $this->_aether_language->get('language', 'fa_1'),
				'FA_2' => $this->_aether_language->get('language', 'fa_2'),
				'FA_3' => $this->_aether_language->get('language', 'fa_3'),
				'FA_4' => $this->_aether_language->get('language', 'fa_4'),
				'FA_5' => $this->_aether_language->get('language', 'fa_5'),
				'FA_6' => $this->_aether_language->get('language', 'fa_6'),
				'FA_7' => $this->_aether_language->get('language', 'fa_7'),
				'DISCORD_BOX_STATUS_1' => $this->_aether_language->get('language', 'discord_box_status_1'),
				'DISCORD_BOX_STATUS_2' => $this->_aether_language->get('language', 'discord_box_status_2'),
				'DISCORD_BOX_TITLE' => $this->_aether_language->get('language', 'discord_box_title'),
				'FOOTER_CREDIT_1' => $this->_aether_language->get('language', 'footer_credit_1'),
				'FOOTER_CREDIT_2' => $this->_aether_language->get('language', 'footer_credit_2'),
				'THEME_SLIDER1_TITLE' => $theme_slider_1_title,
				'THEME_SLIDER2_TITLE' => $theme_slider_2_title,
				'THEME_SLIDER3_TITLE' => $theme_slider_3_title,
				'THEME_SLIDER4_TITLE' => $theme_slider_4_title,
				'THEME_SLIDER5_TITLE' => $theme_slider_5_title,
				'THEME_SLIDER1_DESCRIPTION' => $theme_slider_1_description,
				'THEME_SLIDER2_DESCRIPTION' => $theme_slider_2_description,
				'THEME_SLIDER3_DESCRIPTION' => $theme_slider_3_description,
				'THEME_SLIDER4_DESCRIPTION' => $theme_slider_4_description,
				'THEME_SLIDER5_DESCRIPTION' => $theme_slider_5_description,
				'THEME_SLIDER1_IMAGE' => $theme_slider_1_image,
				'THEME_SLIDER2_IMAGE' => $theme_slider_2_image,
				'THEME_SLIDER3_IMAGE' => $theme_slider_3_image,
				'THEME_SLIDER4_IMAGE' => $theme_slider_4_image,
				'THEME_SLIDER5_IMAGE' => $theme_slider_5_image,
				'THEME_SLIDER1_LINK' => $theme_slider_1_link,
				'THEME_SLIDER2_LINK' => $theme_slider_2_link,
				'THEME_SLIDER3_LINK' => $theme_slider_3_link,
				'THEME_SLIDER4_LINK' => $theme_slider_4_link,
				'THEME_SLIDER5_LINK' => $theme_slider_5_link,
				'PORTAL_1_LINK' => $portal1link,
				'PORTAL_2_LINK' => $portal2link,
				'PORTAL_3_LINK' => $portal3link,
				'PORTAL_4_LINK' => $portal4link,
				'PORTAL_1_NAME' => $portal1name,
				'PORTAL_2_NAME' => $portal2name,
				'PORTAL_3_NAME' => $portal3name,
				'PORTAL_4_NAME' => $portal4name,
				'PORTAL_1_ICON' => $portal1icon,
				'PORTAL_2_ICON' => $portal2icon,
				'PORTAL_3_ICON' => $portal3icon,
				'PORTAL_4_ICON' => $portal4icon,
				'THEME_PORTAL_BG' => $theme_portal_bg,
				'THEME_DISCORD_SERVER' => $theme_discord_server,
				'THEME_FAVICON' => $theme_favicon,
				'THEME_LOGO' => $theme_logo,
				'THEME_BOX_BG' => $theme_box_bg,
				'THEME_BOX_MARGIN' => $theme_box_margin,
				'THEME_BTN_BG' => $theme_btn_bg,
				'THEME_ALERT_TITLE' => $theme_alert_title,
				'THEME_ALERT_TEXT' => $theme_alert_text,
				'THEME_DISCORD_BOX' => $theme_discord_box,
				'THEME_SERVER_BOX' => $theme_server_box,
				'THEME_FA' => $theme_fa,
				'THEME_FONT' => $theme_font,
				'THEME_BG_COLOR' => $theme_bg_color,
				'THEME_BOX_MOBILE' => $theme_box_mobile,
				'THEME_GA' => $theme_ga,
				'THEME_C_OVERLAY' => $theme_c_overlay,
				'THEME_P_COLOR' => $theme_p_color,
				'THEME_S_COLOR' => $theme_s_color,
				'THEME_LOGO_SIZE' => $theme_logo_size,
				'THEME_LOGO_SIZE_M' => $theme_logo_size_m,
				'THEME_LOGO_MARGIN' => $theme_logo_margin,
				'THEME_LOGO_MARGIN_M' => $theme_logo_margin_m,
				'THEME_SLIDER1_DCOLOR' => $theme_slider_1_dcolor,
				'THEME_SLIDER1_TCOLOR' => $theme_slider_1_tcolor,
				'THEME_SLIDER2_DCOLOR' => $theme_slider_2_dcolor,
				'THEME_SLIDER2_TCOLOR' => $theme_slider_2_tcolor,
				'THEME_SLIDER3_DCOLOR' => $theme_slider_3_dcolor,
				'THEME_SLIDER3_TCOLOR' => $theme_slider_3_tcolor,
				'THEME_SLIDER4_DCOLOR' => $theme_slider_4_dcolor,
				'THEME_SLIDER4_TCOLOR' => $theme_slider_4_tcolor,
				'THEME_SLIDER5_DCOLOR' => $theme_slider_5_dcolor,
				'THEME_SLIDER5_TCOLOR' => $theme_slider_5_tcolor,
				'THEME_ANNOUNCE_TITLE' => $theme_announce_title,
				'THEME_ANNOUNCE_TEXT' => $theme_announce_text
			));

		} else {
			if($user->data()->group_id == 2 || $user->hasPermission('admincp.aether')){
				$cache->setCache('panel_sidebar');
				if(!$cache->isCached('aether_order')){
					$order = 35;
					$cache->store('aether_order', 35);
				} else {
					$order = $cache->retrieve('aether_order');
				}

				if(!$cache->isCached('aether_icon')){
					$icon = '<i class="fas fa-palette"></i>';
					$cache->store('aether_icon', $icon);
				} else
					$icon = $cache->retrieve('aether_icon');

				$navs[2]->add('aether_divider', mb_strtoupper($this->_aether_language->get('language', 'aether_title')), 'divider', 'top', null, $order, '');
				$navs[2]->add('aether', $this->_aether_language->get('language', 'aether_title'), URL::build('/panel/aether'), 'top', null, ($order + 0.1), $icon);
			}
		}
	}
}
