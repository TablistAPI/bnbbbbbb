<?php 
/*
 *	Made by Coldfire - https://coldfiredev.cf
 *  NamelessMC version 2.0.0-pr7
 *
 *  Module for Aether Template
 */

$aether_language = new Language(ROOT_PATH . '/modules/Aether/language', LANGUAGE);

if(!isset($admin_sidebar)) $admin_sidebar = array();
$admin_sidebar['aether'] = array(
	'title' => $aether_language->get('language', 'aether_title'),
	'url' => URL::build('/admin/aether')
);

require_once(ROOT_PATH . '/modules/Aether/module.php');
$module = new Aether_Module($pages, $language, $aether_language);